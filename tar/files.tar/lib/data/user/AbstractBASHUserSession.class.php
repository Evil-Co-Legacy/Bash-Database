<?php
require_once(WCF_DIR.'lib/system/session/UserSession.class.php');

class AbstractBASHUserSession extends UserSession {
	
}
?>
