<?php
require_once(BASH_DIR.'lib/data/user/AbstractBASHUserSession.class.php');

class BASHGuestSession extends AbstractBASHUserSession {
	
}
?>
