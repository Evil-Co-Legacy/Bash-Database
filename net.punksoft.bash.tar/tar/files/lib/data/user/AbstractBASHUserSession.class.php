<?php
require_once(WCF_DIR.'lib/system/session/UserSession.class.php');

/**
 * Represents a bash session
 * @author		Johannes Donath
 * @copyright	2010 DEVel Fusion
 * @package		de.evil-co.bash
 */
class AbstractBASHUserSession extends UserSession {
	
}
?>
