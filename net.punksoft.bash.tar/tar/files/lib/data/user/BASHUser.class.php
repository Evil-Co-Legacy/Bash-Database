<?php
require_once(WCF_DIR.'lib/data/user/UserProfile.class.php');

class BASHUser extends UserProfile {
	
}
?>
